<?php
        include 'includes/modal.php';
        include 'includes/common.php';
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>shopping website</title>
  <link rel="stylesheet" href="navbarstyle.css">
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
  <div class="wrapper">
    <nav>
      <input type="checkbox" id="show-menu">
      <label for="show-menu" class="menu-icon"><i class="fas fa-bars"></i></label>
      <div class="content">
      <div class="logo"><a href="index.php">Mobile Shop</a></div>
        <ul class="links">
          <li><a href="index.php">Home</a></li>
          <li><a href="about_us.php">About</a></li>
          <?php
          if(isset($_SESSION["email"]))
          {
            echo "<li><a href='#'>Hi ,$_SESSION[email] </a></li>";
            echo '<li><a href="logout_script.php">LOGOUT</a></li>';
            echo "<li><a href='cart.php'>CART </a></li>";
          }
          else
          {
           echo '<li><a href="signup.php">SIGNUP</a></li>';
            echo '<li><a href="#" data-toggle="modal" data-target="#loginmodal">LOGIN</a></li>';
          }
       ?>
      
          </ul>
      </div>
      </form>
    </nav>
  </div>
</body>
</html>



